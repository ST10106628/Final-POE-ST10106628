package com.mycompany.login;
import javax.swing.JOptionPane;

/**
 *
 * @author U
 */
class Task {
    
     boolean checkTaskDescription(String taskDes)
    {
        if(taskDes.length()<= 50)
        { 
            return true;
        }else{
           return false;  
        }
       
    }
    
    String createTaskID(String taskName,int taskNum,String devDetails){
        
        return taskName.substring(0, 1) + ":"+ taskNum+":"+devDetails.substring(devDetails.length()-3);
        
    }

    int combinedTasksHours (int hours)
    {
     return  hours;
   }
    
    
}
