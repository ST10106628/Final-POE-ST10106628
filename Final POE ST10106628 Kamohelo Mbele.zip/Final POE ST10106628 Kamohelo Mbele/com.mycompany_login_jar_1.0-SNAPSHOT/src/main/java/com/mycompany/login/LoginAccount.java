package com.mycompany.login;

import java.util.regex.Pattern;
import java.util.regex.Matcher;

public class LoginAccount {
	public  boolean checkUserName(String username)
	{
		String regex = "[a-zA-Z0-9 _]{1,5}";
		Pattern p = Pattern.compile(regex);
		if (username==null) {
			return false;
		}
		
		Matcher m = p.matcher(username);
		return m.matches();
	}
	
	

	public static boolean checkPasswordComplexity(String password)
	{
		String regex = "[/^[ A-Za-z0-9_@./*#&+-]*$/]{1,9}";
		Pattern p = Pattern.compile(regex);
		Pattern sPattern =Pattern.compile("[ A-Za-z0-9_]*");
		Matcher sMatcher =sPattern.matcher(password);
		if (!sMatcher.matches()){
			return true;
		}
		
		return false;
	}

	
	public  boolean registerUser(boolean username, boolean password )
	{
		if( username && password )
		{
			return true;
		}
		else {
			return false;
		}


	}

}
