package com.mycompany.login;
import javax.swing.JOptionPane;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextPane;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JSeparator;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JOptionPane;
import javax.swing.JRadioButton;
import javax.swing.SwingConstants;
import java.io.*;
import java.awt.Font;
import javax.swing.UIManager;

import java.awt.Color;


/**
 *
 * @author U
 */
public class Login {
	
	private JFrame frmloginsystem;
	private JTextField txtUserName;
	private JPasswordField passwordField;
	private JPasswordField txtPassword;
	private JTextField txtFirstName;
	private JTextField txtLastName;
	//public static boolean isUserLoginSuccess = false ;
	 Task task = new Task();
     int numTasks =0;
      String[] TaskName= null;// naming the string task name in array
      String[]TaskDescription = null;// naming the string taskdecription in array
      String[] TasksNumber = null;// naming the string tasknumber in array
      String[] DevelopersDetails = null;// naming the string developers details in array
      int[] TaskDuration = null;// string for duration in array
      String [] TaskId = null;// naming taskid in array
      String[] TaskStatus = null;
      int hours =0;
    int option;
    int selectedOption ;
    int optionResults;
    int optionOne =1;// telling the value of the option to be chose by the user
    int optionTwo =2;// telling the value of the option to be chose by the user
    int optionThree =3;// telling the value of the option to be chose by the user
    int optionFour =4;// telling the value of the option to be chose by the user
    int optionFive =5;// telling the value of the option to be chose by the user
    int optionSix = 6;// telling the value of the option to be chose by the user
   public  String taskName = "";
   public String devName ="";
   public String deleteTaskName ="";
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
    	
    	EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Login window = new Login();
					window.frmloginsystem.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
    	
    }	
    	
   
       
        
             public Login() {
		initialize();
	}

private void initialize() {
	frmloginsystem = new JFrame();
	frmloginsystem.getContentPane().setBackground(Color.WHITE);
	frmloginsystem.setBounds(100, 100, 562, 398);
	frmloginsystem.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	frmloginsystem.getContentPane().setLayout(null);
	
	JLabel lblUserName = new JLabel("UserName");
	lblUserName.setBounds(35, 210, 103, 13);
	lblUserName.setFont(new Font("Haettenschweiler", Font.PLAIN, 18));
	frmloginsystem.getContentPane().add(lblUserName);
	
	JLabel lblPassword = new JLabel("Password");
	lblPassword.setBounds(35, 250, 103, 13);
	lblPassword.setFont(new Font("Haettenschweiler", Font.PLAIN, 18));
	frmloginsystem.getContentPane().add(lblPassword);
	
	JTextPane textPane = new JTextPane();
	textPane.setBounds(286, 108, -3, 3);
	frmloginsystem.getContentPane().add(textPane);
	
	txtUserName = new JTextField();
	txtUserName.setBounds(187, 207, 184, 30);
	frmloginsystem.getContentPane().add(txtUserName);
	txtUserName.setColumns(10);
	
	passwordField = new JPasswordField();
	passwordField.setBounds(232, 155, -48, 22);
	frmloginsystem.getContentPane().add(passwordField);
	
	txtPassword = new JPasswordField();
	txtPassword.setBounds(187, 247, 182, 19);
	frmloginsystem.getContentPane().add(txtPassword);
	
	JButton btnLogin = new JButton("Login");
	btnLogin.setBackground(UIManager.getColor("CheckBox.focus"));
	btnLogin.setBounds(105, 330, 85, 21);
	btnLogin.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
	       
	            
			
			String fileName = "LoginDetails.txt";

	        // This will reference one line at a time
	        String line = null;

	        try {
	            // FileReader reads text files in the default encoding.
	            FileReader fileReader = 
	                new FileReader(fileName);

	            // Always wrap FileReader in BufferedReader.
	            BufferedReader bufferedReader = 
	                new BufferedReader(fileReader);
	            String filePassword = "" ;
            	String fileUserName ="";

	            while((line = bufferedReader.readLine()) != null) {
	               // System.out.println(line);
	            	
	            	if(line.contains("password"))
	            			{
	            				 filePassword = line.replaceAll(" ", "").substring(9,line.length()-1 );
	            			}
	            	
	            	 if(line.contains("username"))
	            			{
	            				 fileUserName = line.replaceAll(" ", "").substring(9,line.length()-1);
	            			}
	            	
	            	
	            	
	            }   

	            // Always close files.
	            bufferedReader.close();  
	            String inputPassword =txtPassword.getText().toString();
	            String inputUserName =txtUserName.getText().toString();
	            
	            
	            if(filePassword.equals(inputPassword)  &&  fileUserName.equals(inputUserName))	
            	{
            		JOptionPane.showMessageDialog(null, "login succesfull","Succesful Login",JOptionPane.INFORMATION_MESSAGE);
            		JOptionPane.showMessageDialog(null,"Welcome Easy_Kanban");
            		frmloginsystem.setVisible(false);
            		do{
                        option = Integer.parseInt(JOptionPane.showInputDialog
                            ("Please select the option by entering the "
                            +"value next to the option\n"+
                            "1)Add Tasks\n"+
                            "2)Show Report\n"+     
                            "3)Quit"));
                        
                         
                        if(option == 1){
                            
                             
                         numTasks = Integer.parseInt(JOptionPane.showInputDialog(null,
                            "please Enter number of task"));
                    
                    TaskName = new String[numTasks];
                    TasksNumber = new   String[numTasks];
                   TaskDescription  = new  String[numTasks];
                   DevelopersDetails = new String[numTasks];
                    TaskDuration = new int[numTasks];
                    TaskId = new String[numTasks];
                    TaskStatus = new String[numTasks];
                   String taskDescription;
                   boolean isTaskDescValid = false;
                   int taskStatus;
                   String taskOption = null;
                   int combinedTasksHours = 0;
                   int durationOfTasks = 0;
                    

                   

                        
                            for(int i = 0; i < TasksNumber.length; i++){
                                
                                
                       
                         
                         String nameOfTask = JOptionPane.showInputDialog
                    (null, "pleaseEnter the task name " + (i + 1));
                        
                        
                         
                        String developmentDetails =JOptionPane.showInputDialog
                    (null, "please Enter developers details "); 
                          
                    
                  
                     do{
                             taskDescription = JOptionPane.showInputDialog
                         (null, "please Enter task description " + (i + 1));
                            isTaskDescValid = task.checkTaskDescription(taskDescription);
                           
                           if(!isTaskDescValid)
                           {
                               JOptionPane.showInputDialog
                         (null, "Please enter a task description of less than 50 characters ");
                           }
                           else{
                             
                               JOptionPane.showMessageDialog
                         (null, "Task  sucessfully captured ");
                              
                           }
                     }while(!isTaskDescValid);
                     
                      String generatedTaskID = task.createTaskID(nameOfTask, i, developmentDetails);
                     String  iterationCounter = String.valueOf(i);
                     do{
                             taskStatus = Integer.parseInt(JOptionPane.showInputDialog
                            ("Please select the task status option by entering the "
                            +"value next to the option\n"+
                            "1)To Do\n"+
                            "2)Done\n"+     
                            "3)Doing"));
                            
                              if(taskStatus == 1)
                              {
                                  taskOption ="To Do";
                              }
                              
                             if(taskStatus == 2)
                             {
                                 taskOption ="Done";
                             }
                             
                             if(taskStatus == 3)
                             {
                                 taskOption = "Doing";
                             }
                             
                    }while((taskStatus != 1) && (taskStatus != 2)&& (taskStatus != 3));
                    
                       
                      
                        
                    
                       int taskDuration = Integer.parseInt(JOptionPane.showInputDialog
                    (null, "Enter  task duration " + (i + 1)));
                
                           
                   
                        
                       TaskName[i] = nameOfTask;
                       TasksNumber[i] = iterationCounter;
                       TaskDescription[i] =  taskDescription;
                       DevelopersDetails[i] = developmentDetails;
                       TaskDuration[i] = taskDuration;
                       TaskId[i] = generatedTaskID;
                       TaskStatus[i] = taskOption;
                       combinedTasksHours += task.combinedTasksHours(TaskDuration[i]);
                       durationOfTasks = TaskDuration[i];
                       hours = combinedTasksHours;
                      
                        
                    }
//                           
                        }
                        
                        if(option == 2)
                        {
                          JOptionPane.showMessageDialog(null, "report can only be shown when the user has added a task");
                        	      	
                        	
                        }
                        
                    }while((option != 1) && (option != 2));
            		
            		
            		do{
            			
            			StringBuilder sb = new StringBuilder();// an imported method
//                      
                     
            					
            					 selectedOption = Integer.parseInt(JOptionPane.showInputDialog
            							 // below here we have the option to be chosen by the user after login success
                            ("Please select the option by entering the "
                            +"value next to the option\n"+
                            "1)Show Reports\n"+  
                            "2)Quit the application\n"));
                        
                        if(selectedOption == 1) 
                        {
                        	optionResults =ShowReport.reportDashboard( sb );
                        	
		                        	if(optionResults == optionOne)
		                        	{
		                        		// the ;ine below cpntains for loop which help to display the amount of taskstatus prompted by the user
		                        		 for(int i = 0; i < TasksNumber.length; i++){
		                        			 if( TaskStatus[i].equalsIgnoreCase("Done")) {
		                        				 // below here we have the prompt displayed
		                                     sb.append("Task Status: " + TaskStatus[i]+ "\n"+
		                                               "Developers Details: " +DevelopersDetails[i]+"\n"+
		                                               "Task Name: " +TaskName[i]+"\n"+
		                                             "Task Duration: " + TaskDuration[i] + "\n\n");
		                                 }
		                        		 }
		                        		ShowReport.statusOfDone(sb);
		                        	}
		                        	
		                        	if(optionResults == optionTwo)
		                        	{
		                        		int maxDuaration =TaskDuration[0];
		                        		int count = 0;// declaring the count 
		                        		 for(int i = 0; i < TasksNumber.length; i++){// this loop helps to detemine the task with the longest duration by using the maxDuration method and also some arrays ,
		                        			if(maxDuaration < TaskDuration[i])
		                        			{
		                        				maxDuaration=TaskDuration[i];
		                        				count=i;
		                        				}
		                        			}
		                               
		                        		 sb.append(
	                                               "Developers Details: " +DevelopersDetails[count]+"\n"
	                                          + "Task Duration: " + TaskDuration[count] + "\n\n");
		                        		ShowReport.longestDuration(sb);
		                        	}
		                        	if(optionResults == optionThree)
		                        	{
		                        		taskName =JOptionPane.showInputDialog
		                                         ("Please enter the name of the task to search " );// prompting user to enter the task name he wishes to search
		                        		 for(int i = 0; i < TasksNumber.length; i++){
		                        			 
		                        			 if(taskName.equalsIgnoreCase(TaskName[i]))
		                        			 {
		                        				 		sb.append("Task Status: " + TaskStatus[i]+ "\n"+//displaying all that has been searched by the user
		                                               "Developers Details: " +DevelopersDetails[i]+"\n"+
		                                               "Task Name: " +TaskName[i]+"\n\n");
		                        			 }       
		                                              		                                            
		                                 }
		                        		 ShowReport.searchTaskName(sb);
		                        	}
		                        	if(optionResults == optionFour)// thsi line tells what happens when the user has enter the  fourth options
		                        	{
		                        		devName =JOptionPane.showInputDialog
		                                         ("Please enter the name of the Developer Name to search " );// prompting the user to enter the name of the developer
		                        		 for(int i= 0; i < TasksNumber.length; i++){
		                        			 
		                        			 if(devName.equalsIgnoreCase(DevelopersDetails[i]))// displaying all the developer details
		                        			 {
		                        				 		sb.append("Task Status: " + TaskStatus[i]+ "\n"+
		                                               "Task Name: " +TaskName[i]+"\n\n");
		                        			 }       
		                                 
		                        		 }
		                        		 ShowReport.searchTaskName(sb);
		                        	}
		                        	
		                        	if(optionResults == optionFive)
		                        	{
		                        		deleteTaskName =JOptionPane.showInputDialog
		                                         ("Please enter the name of the Task Name to delete" );
		                        		int count = 0;
		                        		 for(int i = 0; i < TasksNumber.length; i++){
		                        			if(deleteTaskName.equalsIgnoreCase(TaskName[i])) {
		                        				count =i;
		                        				}
		                        			}
		                               
		                        		 String[] TaskNameCopy= new  String[TaskName.length-1] ;
		                        	      String[]TaskDescriptionCopy = new String[TaskDescription.length-1] ;
		                        	      String[] TasksNumberCopy = new String[TasksNumber.length-1] ;
		                        	      String[] DevelopersDetailsCopy = new String[ DevelopersDetails.length-1] ;
		                        	      int[] TaskDurationCopy = new int[TaskDuration.length-1] ;
		                        	      String [] TaskIdCopy =new String[TaskId.length-1] ;
		                        	      String[] TaskStatusCopy = new String[TaskStatus.length-1] ;
		                        	      // below the codes are use in array helping to delete the task not needed and displaying just the task remain
		                        	      
		                        	      System.arraycopy(TaskName, 0, TaskNameCopy, 0, count);
		                        	      System.arraycopy(TaskDescription, 0, TaskDescriptionCopy, 0, count); 
		                        	      System.arraycopy(TasksNumber, 0, TasksNumberCopy, 0, count); 
		                        	      System.arraycopy(DevelopersDetails, 0, DevelopersDetailsCopy, 0, count); 
		                        	      System.arraycopy(TaskDuration, 0, TaskDurationCopy, 0, count); 
		                        	      System.arraycopy(TaskId, 0, TaskIdCopy, 0, count); 
		                        	      System.arraycopy(TaskStatus, 0, TaskStatusCopy, 0, count); 
		                        	      
		                        	      System.arraycopy(TaskName,count + 1,TaskNameCopy,count, TaskName.length - count - 1);
		                        	      System.arraycopy(TaskDescription,count + 1,TaskDescriptionCopy,count, TaskName.length - count - 1);
		                        	      System.arraycopy(TasksNumber,count + 1,TasksNumberCopy,count, TaskName.length - count - 1);
		                        	      System.arraycopy( DevelopersDetails,count + 1, DevelopersDetailsCopy,count, TaskName.length - count - 1);
		                        	      System.arraycopy( TaskDuration,count + 1, TaskDurationCopy,count, TaskName.length - count - 1);
		                        	      System.arraycopy( TaskId,count + 1, TaskIdCopy,count, TaskName.length - count - 1);
		                        	      System.arraycopy( TaskStatus,count + 1, TaskStatusCopy,count, TaskName.length - count - 1);
		                        	      sb.append("A task has been deleted.\n below is the remaining task\nTask Details\n"+
			                                      "*********************************\n");
			                             for(int i = 0; i < TasksNumber.length; i++){
			                                  sb.append("Task Status: " + TaskStatus[i]+ "\n"+
			                                            "Developers Details: " +DevelopersDetails[i]+"\n"+
			                                           "Tasks Number: " + TasksNumber[i]+"\n"+
			                                            "Task Name: " +TaskName[i]+"\n"+
			                                              " Task Description : " + TaskDescription[i]+"\n"+
			                                             "Task Id: " + TaskId[i]+"\n"+
			                                          "Task Duration: " + TaskDuration[i] + "\n\n");
		                        		ShowReport.deleteTask(sb);
			                              }
		                        	}
		                        	// the codes below display a full report by using the for loop which still helps display the countless amount of task added
		                        	
		                        	if(optionResults == optionSix) {
		                        		 sb.append("Task Details\n"+
	                                      "*********************************\n");
	                              for(int i = 0; i < TasksNumber.length; i++){
	                                  sb.append("Task Status: " + TaskStatus[i]+ "\n"+
	                                            "Developers Details: " +DevelopersDetails[i]+"\n"+
	                                           "Tasks Number: " + TasksNumber[i]+"\n"+
	                                            "Task Name: " +TaskName[i]+"\n"+
	                                              " Task Description : " + TaskDescription[i]+"\n"+
	                                             "Task Id: " + TaskId[i]+"\n"+
	                                          "Task Duration: " + TaskDuration[i] + "\n\n");
	                              }
	                              ShowReport.displayReport(sb);
		                        	}
                        }
                        // below if the user selected option2 it tell him to exit the page 
                        if(selectedOption == 2)
                        {
                        	System.exit(0);
                        }
            		}while((selectedOption != 1) && (selectedOption != 2));// while loop implemented sunce it is a condtion
                              
                       
                   
	        
            	}
	            else	 {
            		JOptionPane.showMessageDialog(null, "In Valid Password or Username","UnSuccesful Login",JOptionPane.ERROR_MESSAGE); 
            	}
	        }
	        catch(FileNotFoundException ex) {
	            System.out.println(
	                "Unable to open file '" + 
	                fileName + "'");                
	        }
	        catch(IOException ex) {
	            System.out.println(
	                "Error reading file '" 
	                + fileName + "'");                  
	         
	        }
			
		}
	});
	frmloginsystem.getContentPane().add(btnLogin);
	
	JButton btnReset = new JButton("delete");
	btnReset.setBackground(UIManager.getColor("CheckBox.foreground"));
	btnReset.setBounds(232, 330, 85, 21);
	btnReset.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			txtUserName.setText(null);
			txtPassword.setText(null);
			txtFirstName.setText(null);
			txtLastName.setText(null);
		}
	});
	frmloginsystem.getContentPane().add(btnReset);
	
	JButton btnExit = new JButton("Exit");
	btnExit.setBackground(UIManager.getColor("CheckBox.foreground"));
	btnExit.setBounds(346, 330, 85, 21);
	btnExit.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			frmloginsystem = new JFrame("Reset");
			if (JOptionPane.showConfirmDialog(frmloginsystem,"please Confirm to exist","loginsystem",JOptionPane.YES_NO_OPTION)==JOptionPane.YES_NO_OPTION) {
				System.exit(0);
			}
		}
	});
	frmloginsystem.getContentPane().add(btnExit);
	
	JSeparator separator = new JSeparator();
	separator.setBounds(24, 285, 366, 3);
	frmloginsystem.getContentPane().add(separator);
	
	JSeparator separator_1 = new JSeparator();
	separator_1.setBounds(24, 95, 366, 3);
	frmloginsystem.getContentPane().add(separator_1);
	
	JLabel lblFirstName = new JLabel("FirstName");
	lblFirstName.setBounds(35, 124, 103, 13);
	lblFirstName.setFont(new Font("Haettenschweiler", Font.PLAIN, 18));
	frmloginsystem.getContentPane().add(lblFirstName);
	
	JLabel lblLastName = new JLabel("LastName");
	lblLastName.setBounds(35, 171, 103, 13);
	lblLastName.setFont(new Font("Haettenschweiler", Font.PLAIN, 18));
	frmloginsystem.getContentPane().add(lblLastName);
	
	txtFirstName = new JTextField();
	txtFirstName.setBounds(187, 121, 184, 19);
	frmloginsystem.getContentPane().add(txtFirstName);
	txtFirstName.setColumns(10);
	
	txtLastName = new JTextField();
	txtLastName.setBounds(187, 168, 184, 19);
	frmloginsystem.getContentPane().add(txtLastName);
	txtLastName.setColumns(10);
	
	
	JRadioButton rdbtnLogin = new JRadioButton("Login");
	rdbtnLogin.setBounds(35, 41, 103, 21);
	rdbtnLogin.setFont(new Font("Haettenschweiler", Font.PLAIN, 20));
	frmloginsystem.getContentPane().add(rdbtnLogin);
	
	JRadioButton rdbtnRegistration = new JRadioButton("Registeration");
	rdbtnRegistration.setBounds(328, 41, 103, 21);
	rdbtnRegistration.setFont(new Font("Haettenschweiler", Font.PLAIN, 20));
	frmloginsystem.getContentPane().add(rdbtnRegistration);
	
	ButtonGroup group = new ButtonGroup();
	group.add(rdbtnLogin);
	group.add(rdbtnRegistration);
	
	JLabel lblHeader = new JLabel("");
	lblHeader.setBounds(222, 10, 95, 13);
	frmloginsystem.getContentPane().add(lblHeader);
	
	JButton btnSubmit = new JButton("register");
	btnSubmit.setBackground(UIManager.getColor("MenuItem.selectionBackground"));
	btnSubmit.setBounds(10, 330, 85, 21);
	btnSubmit.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			
			String password = txtPassword.getText();
			String username = txtUserName.getText();
			String firstname =txtFirstName.getText();
			String lastname =txtLastName.getText();
			
			LoginAccount login = new LoginAccount();
			boolean isUserNameValid = false;
			boolean isPasswordValid = false;
			boolean isLoginDeatailsValid = false;
			
			 
			if(password != null || username != null) {
				txtPassword.setText(null);
			    txtUserName.setText(null);
			    
			    
			   isUserNameValid = login.checkUserName(username);
			   
			  
			   
			    if (!isUserNameValid)
			    {
			    	JOptionPane.showMessageDialog(null, "please ensure that your username should contain an underscore and not mo than 5 characters ","Username is not correctly formatted",JOptionPane.ERROR_MESSAGE);  	
			    }
			     isPasswordValid =    login.checkPasswordComplexity(password);
			    if (! isPasswordValid)
			    {
			    	JOptionPane.showMessageDialog(null, "password should be 8 characters long,contains a capital letter,contain a number,contain a special character"
			    			+ "","InValid Password",JOptionPane.ERROR_MESSAGE);  	
			    }
			    
			}
			else {
				JOptionPane.showMessageDialog(null, "InValid Login Details","Login Error",JOptionPane.ERROR_MESSAGE);
				
				txtPassword.setText(null);
			    txtUserName.setText(null);
			}
			
			isLoginDeatailsValid = 	login.registerUser(isUserNameValid ,isPasswordValid);
			
			if(isLoginDeatailsValid) {
				
				String fileName = "LoginDetails.txt";
				
				 try {
			            // Assume default encoding.
			            FileWriter fileWriter =
			                new FileWriter(fileName);

			            // Always wrap FileWriter in BufferedWriter.
			            BufferedWriter bufferedWriter =
			                new BufferedWriter(fileWriter);

			            // Note that write() does not automatically
			            // append a newline character.
			            bufferedWriter.write("password :" +password);
			            bufferedWriter.newLine();
			            bufferedWriter.write("username :" + username);
			            bufferedWriter.newLine();
			            bufferedWriter.write("firstname :" + firstname);
			            bufferedWriter.newLine();
			            bufferedWriter.write("lastname :"+ lastname);

			            // Always close files.
			            bufferedWriter.close();
			            
			         
			            JOptionPane.showMessageDialog(null, "UserName and Password Succesfully Captured","Succesful Registration",JOptionPane.INFORMATION_MESSAGE);
			            JOptionPane.showMessageDialog(null, "please click on the login button to Login " ,"",JOptionPane.INFORMATION_MESSAGE);
			            String inputPassword =txtPassword.getText().toString();
			            String inputUserName =txtUserName.getText().toString();
			            
			        
			            txtFirstName.setText("");
			            txtLastName.setText("");
			            txtUserName.setText("");
			            txtPassword.setText("");
			        }
			        catch(IOException ex) {
			            System.out.println(
			                "Error writing to file '"
			                + fileName + "'");
			          
			        }
				
			}
		}
	});
	btnSubmit.setHorizontalAlignment(SwingConstants.RIGHT);
	
	frmloginsystem.getContentPane().add(btnSubmit);
	
	JLabel lblNewLabel = new JLabel("LOGIN & REGISTRATION");
	lblNewLabel.setBounds(164, 0, 226, 23);
	lblNewLabel.setFont(new Font("Haettenschweiler", Font.PLAIN, 26));
	frmloginsystem.getContentPane().add(lblNewLabel);
	
	rdbtnLogin.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
	       
			txtFirstName.setVisible(false);
			txtLastName.setVisible(false);
			lblFirstName.setVisible(false);
			lblLastName.setVisible(false);
			lblHeader.setText("Login");
			btnLogin.setVisible(true);
			btnSubmit.setVisible(false);

			
			
		}

	});
	
	rdbtnRegistration.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
	       
			txtFirstName.setVisible(true);
			txtLastName.setVisible(true);
			lblFirstName.setVisible(true);
			lblLastName.setVisible(true);
			btnLogin.setVisible(false);
			btnSubmit.setVisible(true);
			
			lblHeader.setText("Registration");
		}

	});
}
}


        // TODO code application logic here
    