package com.mycompany.login;
import javax.swing.JOptionPane;


public class ShowReport {
	public static int reportOption;
	public static int reportDashboard( StringBuilder info)
	{
		int results =0;
		do {
			reportOption= Integer.parseInt(JOptionPane.showInputDialog// the following below provide the options for which the user want to show report
                    ("Please select the option by entering the "
                    +"value next to the option\n"+
                    "(1)Display the Developer, Task Names and Task Duration for all the tasks\n"+
                    "(2)Display the developer longest duration\n"+     
                    "(3)Search for a Task with TaskName and Display the Task Name, Developer and Task Status\n"+
                    "(4)Search for all task aasigned to a developer and display the Task Name and TaskStaus\n" +
  		          "(5)Delete a task using TaskName\n"+
                    "(6)Display a report that list the full details of all captured tasks\n"+
  		          "(7)EXIT"));
  		 
  		  if(reportOption == 1) {
  			results = 1;// below the reeport options are  returning the  int values
  		  }
  		   if(reportOption == 2) {
  			 results = 2;
  			  }
  		  if(reportOption==3) {
  			results = 3;
  		  }
  		  if(reportOption==4) {
  			results = 4;
  		  }
  		 if(reportOption==5) {
  			results = 5;
  		  }
  		 
  		 if(reportOption==6) {
  			results = 6;
 		  }

  		
  		 if(reportOption==7) {
  			 System.exit(0);
  			results = -1;
    		  }
  		  }
  	
  	while(reportOption != 1&& (reportOption !=2) &&(reportOption !=3) && (reportOption !=4)&&  (reportOption !=5)&& (reportOption !=6));
  	
  	return results ;
	}

	public static void statusOfDone(StringBuilder sd)//the following lines below accept the retiurn code due to void and display by the use of JOptionPane
	{
				JOptionPane.showMessageDialog(null, sd);
		
	}
 public static void longestDuration(StringBuilder td) {
	 
	 JOptionPane.showMessageDialog(null, td);
 }
 public static void searchTaskName(StringBuilder st) {
	 JOptionPane.showMessageDialog(null, st);
 }
 public static void searchTaskStatus(StringBuilder dd ) {
	 JOptionPane.showMessageDialog(null, dd);
 }
 public static void deleteTask(StringBuilder dl) {
	 
	
	 JOptionPane.showMessageDialog(null, dl);
 }
 public static void displayReport(StringBuilder sb) {
	 
	 sb.append("\n*********************************\n"); JOptionPane.showMessageDialog(null, sb);
 }
}
